package Lab3;


public interface EmailRecipient {
    String getEmailAddress();
}
